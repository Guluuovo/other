create extension if not exists pgcrypto;
create table if not exists public.chef_profiles (user_id uuid primary key references auth.users(id) on delete cascade);
create table if not exists public.dishes (
 id uuid primary key default gen_random_uuid(), name text not null, image text not null default '', category text not null,
 description text not null default '', status text not null check(status in ('已完成','研发中','想做')),
 orderable boolean not null default false, tag text, sort_order integer not null default 0, visible boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.orders (
 id uuid primary key default gen_random_uuid(), nickname text not null check(char_length(nickname) between 1 and 30),
 items jsonb not null check(jsonb_typeof(items)='array' and jsonb_array_length(items) between 1 and 20),
 meal_date date, note text not null default '', status text not null default '待确认' check(status in ('待确认','已接受','已完成','已拒绝','已取消')),
 lookup_token text not null unique, created_at timestamptz not null default now()
);
alter table public.dishes enable row level security;
alter table public.orders enable row level security;
alter table public.chef_profiles enable row level security;
create policy "public reads visible dishes" on public.dishes for select using (visible=true or exists(select 1 from public.chef_profiles where user_id=auth.uid()));
create policy "chef manages dishes" on public.dishes for all using (exists(select 1 from public.chef_profiles where user_id=auth.uid())) with check (exists(select 1 from public.chef_profiles where user_id=auth.uid()));
create policy "chef reads orders" on public.orders for select using (exists(select 1 from public.chef_profiles where user_id=auth.uid()));
create policy "chef updates orders" on public.orders for update using (exists(select 1 from public.chef_profiles where user_id=auth.uid())) with check (exists(select 1 from public.chef_profiles where user_id=auth.uid()));
grant select on public.dishes to anon, authenticated;
grant all on public.dishes to authenticated;
grant select,update on public.orders to authenticated;
grant insert on public.orders to service_role;
grant select on public.chef_profiles to authenticated;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('dish-photos','dish-photos',true,5242880,array['image/jpeg','image/png','image/webp']) on conflict (id) do nothing;
create policy "public reads dish photos" on storage.objects for select using (bucket_id='dish-photos');
create policy "chef uploads dish photos" on storage.objects for insert to authenticated with check (bucket_id='dish-photos' and exists(select 1 from public.chef_profiles where user_id=auth.uid()));
create policy "chef updates dish photos" on storage.objects for update to authenticated using (bucket_id='dish-photos' and exists(select 1 from public.chef_profiles where user_id=auth.uid()));
create policy "chef deletes dish photos" on storage.objects for delete to authenticated using (bucket_id='dish-photos' and exists(select 1 from public.chef_profiles where user_id=auth.uid()));
-- 首位主厨在 Auth 中建号后，填入用户 UUID 执行：
-- insert into public.chef_profiles(user_id) values ('00000000-0000-0000-0000-000000000000');
insert into public.dishes(name,category,description,status,orderable,tag,image,sort_order,visible) values
('奶油蘑菇烩饭','暖暖主食','奶香裹着软糯米粒，撒一把黑胡椒就很满足。','已完成',true,'人气','https://images.unsplash.com/photo-1476124369491-e7a?auto=format&fit=crop&w=900&q=85',1,true),
('蜂蜜照烧鸡腿','暖暖主食','甜甜咸咸的酱汁，配白饭刚刚好。','已完成',true,'今日推荐','https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=900&q=85',2,true),
('南瓜浓汤','暖暖汤汤','秋天颜色的一碗汤，温柔又暖胃。','已完成',true,null,'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=85',3,true),
('草莓云朵松饼','甜甜点心','松软得像云朵，顶上有新鲜草莓和奶油。','研发中',false,null,'https://images.unsplash.com/photo-1528207776546-365bb710ee93?auto=format&fit=crop&w=900&q=85',4,true) on conflict do nothing;
