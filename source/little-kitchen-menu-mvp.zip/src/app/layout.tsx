import './globals.css';
import type { Metadata } from 'next';
export const metadata:Metadata={title:'小厨房开饭啦！',description:'家里的菜单小角落，今天想吃什么呢？'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="zh-CN"><body>{children}</body></html>}
