import { NextRequest,NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
const hits=new Map<string,{n:number,t:number}>();
export async function POST(req:NextRequest){
 const ip=req.headers.get('x-forwarded-for')?.split(',')[0]||'unknown',now=Date.now(),old=hits.get(ip);
 if(old&&now-old.t<60000&&old.n>=5)return NextResponse.json({error:'提交太频繁啦，请稍等一会儿。'},{status:429});
 hits.set(ip,!old||now-old.t>=60000?{n:1,t:now}:{n:old.n+1,t:old.t});
 const url=process.env.NEXT_PUBLIC_SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(!url||!key)return NextResponse.json({demo:true});
 try{const body=await req.json();if(typeof body.nickname!=='string'||body.nickname.trim().length<1||body.nickname.length>30||!Array.isArray(body.items)||!body.items.length||body.items.length>20) return NextResponse.json({error:'点菜信息不完整。'},{status:400});
 const supabase=createClient(url,key);const ids=[...new Set(body.items.map((x:{dish_id:string})=>String(x.dish_id)))];
 const {data:dishes,error:readError}=await supabase.from('dishes').select('id,name,orderable,visible').in('id',ids);
 if(readError)throw readError;const allowed=new Map((dishes||[]).filter(d=>d.visible&&d.orderable).map(d=>[d.id,d.name]));
 const items=body.items.filter((x:{dish_id:string})=>allowed.has(String(x.dish_id))).map((x:{dish_id:string;quantity:number})=>({dish_id:String(x.dish_id),name:allowed.get(String(x.dish_id))!,quantity:Math.min(20,Math.max(1,Number(x.quantity)||1))}));
 if(!items.length)return NextResponse.json({error:'篮子里没有当前开放点菜的菜品。'},{status:400});
 const token=crypto.randomUUID()+crypto.randomUUID();const {error}=await supabase.from('orders').insert({nickname:body.nickname.trim(),items,meal_date:body.meal_date||null,note:String(body.note||'').slice(0,500),status:'待确认',lookup_token:token});
 if(error)throw error;return NextResponse.json({ok:true,token});
 }catch(e){return NextResponse.json({error:'暂时没有送达，请稍后再试。'},{status:503})}
}
