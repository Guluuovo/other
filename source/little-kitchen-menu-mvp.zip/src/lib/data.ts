export type Dish = { id:string; name:string; category:string; description:string; status:'已完成'|'研发中'|'想做'; orderable:boolean; tag?:string; image:string; visible:boolean };
export const demoDishes:Dish[]=[
 {id:'d1',name:'奶油蘑菇烩饭',category:'暖暖主食',description:'奶香裹着软糯米粒，撒一把黑胡椒就很满足。',status:'已完成',orderable:true,tag:'人气',image:'https://images.unsplash.com/photo-1476124369491-e7aaddc5e2?auto=format&fit=crop&w=900&q=85',visible:true},
 {id:'d2',name:'蜂蜜照烧鸡腿',category:'暖暖主食',description:'甜甜咸咸的酱汁，配白饭刚刚好。',status:'已完成',orderable:true,tag:'今日推荐',image:'https://images.unsplash.com/photo-1532550907401-a500c9a57435?auto=format&fit=crop&w=900&q=85',visible:true},
 {id:'d3',name:'草莓云朵松饼',category:'甜甜点心',description:'松软得像云朵，顶上有新鲜草莓和奶油。',status:'研发中',orderable:false,image:'https://images.unsplash.com/photo-1528207776546-365bb710ee93?auto=format&fit=crop&w=900&q=85',visible:true},
 {id:'d4',name:'南瓜浓汤',category:'暖暖汤汤',description:'秋天颜色的一碗汤，温柔又暖胃。',status:'已完成',orderable:true,image:'https://images.unsplash.com/photo-1547592180-85f173990554?auto=format&fit=crop&w=900&q=85',visible:true},
 {id:'d5',name:'抹茶巴斯克',category:'甜甜点心',description:'想做一款茶香浓浓、中心软软的蛋糕。',status:'想做',orderable:false,tag:'心愿菜',image:'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=900&q=85',visible:true},
 {id:'d6',name:'蒜香奶油虾',category:'暖暖主食',description:'蒜香和奶油在锅里碰面，面包也要准备好。',status:'已完成',orderable:true,image:'https://images.unsplash.com/photo-1625944525533-473f1a3d54e7?auto=format&fit=crop&w=900&q=85',visible:true},
];
export const categories=['全部','暖暖主食','暖暖汤汤','甜甜点心'];
