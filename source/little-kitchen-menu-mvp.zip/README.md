# 小厨房开饭啦！

家庭共享菜单 H5 MVP。支持公开菜单、分类与状态筛选、详情、点菜篮子、真实云端请求、主厨登录查看和更新请求状态。未配置云端时显示内置演示菜单；演示点菜只显示本机反馈，不会冒充送达。

## 本地启动

1. 安装 Node.js 20 或更新版本。
2. 复制 `.env.example` 为 `.env.local`。留空环境变量可以直接看演示模式。
3. 运行 `npm install`，再运行 `npm run dev`，访问 http://localhost:3000。

## 配置 Supabase

1. 新建 Supabase 项目，在 SQL Editor 执行 `supabase/init.sql`。
2. 在 Authentication 中创建主厨账号，将其 Auth UUID 插入 `chef_profiles`（SQL 文件末尾有示例）。
3. 从 Project Settings → API 复制 Project URL、anon key 和 service_role key，放进 `.env.local`：

```env
NEXT_PUBLIC_SUPABASE_URL=https://你的项目.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=你的anon-key
SUPABASE_SERVICE_ROLE_KEY=你的service-role-key
```

service_role key 只在服务端使用，不能放入 `NEXT_PUBLIC_` 变量，也不要提交到 Git。重新启动开发服务器。菜单读取公开菜品；订单由服务端 API 校验后写入数据库，状态查询由随机 UUID 令牌授权，主厨通过 Supabase Auth 登录。`/api/order` 含每 IP 每分钟 5 次的轻量限制；部署时建议再在托管层启用 WAF/rate limiting。

## 部署

部署至 Vercel，导入项目并添加上述三个环境变量，然后部署。SQL 初始化及主厨 UUID 授权只需各执行一次。设置随机 `MENU_SLUG` 后，分享 `https://你的域名/随机串`；其他路径会返回 404。请勿把此链接公开传播。图片上传使用 Supabase Storage 的 `dish-photos` 桶。

## MVP 范围

主厨登录、菜品新增/编辑/删除、图片上传、分类字段维护、上架/隐藏、点菜开关和请求状态更新均接通 Supabase。初始化数据里的示例图片是外部图片。演示模式数据为静态样例，不会跨设备同步。
