import {NextRequest,NextResponse} from 'next/server';
export function middleware(req:NextRequest){const slug=process.env.MENU_SLUG;if(!slug)return NextResponse.next();const path=req.nextUrl.pathname;if(path==='/kitchen'||path.startsWith('/api/')||path.startsWith('/order/')||path.startsWith('/_next/')||path==='/favicon.ico')return NextResponse.next();if(path===`/${slug}`) {const url=req.nextUrl.clone();url.pathname='/';return NextResponse.rewrite(url)}return new NextResponse('菜单链接无效。',{status:404})}
export const config={matcher:['/:path*']};
